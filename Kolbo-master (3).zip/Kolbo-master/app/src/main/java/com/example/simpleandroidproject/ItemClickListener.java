package com.example.simpleandroidproject;

public interface ItemClickListener {
	 public void addNewItem(ItemsAdapter adapter, int position  , Double total, int numberOfItems); 
}
