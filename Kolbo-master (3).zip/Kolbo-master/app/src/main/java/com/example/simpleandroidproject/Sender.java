package com.example.simpleandroidproject;

public interface Sender {
	
	public void send(); 
	

}
